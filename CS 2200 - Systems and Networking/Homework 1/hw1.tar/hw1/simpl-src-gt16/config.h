#define SIZEOF_INT 4
#define SIZEOF_SHORT 2
#define SIZEOF_LONG 4
#define SIZEOF_PTR 4
#define NO_READLINE
#define USE_KDE
#define INSTALLPATH "/usr/local/simplc"
#define VERSION_STRING "2.1.1b2"
