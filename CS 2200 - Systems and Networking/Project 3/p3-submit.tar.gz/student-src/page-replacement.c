#include <stdlib.h>

#include "types.h"
#include "pagetable.h"
#include "global.h"
#include "process.h"

/*******************************************************************************
 * Finds a free physical frame. If none are available, uses a clock sweep
 * algorithm to find a used frame for eviction.
 *
 * @return The physical frame number of a free (or evictable) frame.
 */
pfn_t get_free_frame(void) {
   int i;
   int found = 0;

   /* See if there are any free frames */
   for (i = 0; i < CPU_NUM_FRAMES; i++)
      if (rlt[i].pcb == NULL)
         return i;

   for (i = 0; i < CPU_NUM_FRAMES; i++) 
   	if(rlt[i].pcb->pagetable[(rlt[i].vpn)].valid == 0)
   		return i;
   	
   while (!found)	
	   for (i = 0; i < CPU_NUM_FRAMES; i++) {
	   	if(rlt[i].pcb->pagetable[(rlt[i].vpn)].used == 0)
	   		found = 1;
	   	else
	   		rlt[i].pcb->pagetable[(rlt[i].vpn)].used = 0;
	   	
	   	if(found)
	   		return i;
	   }
  

   /* If all else fails, return a random frame */
   return rand() % CPU_NUM_FRAMES;
}
