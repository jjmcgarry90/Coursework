#include "my_malloc.h"

/* You *MUST* use this macro when calling my_sbrk to allocate the 
 * appropriate size. Failure to do so may result in an incorrect
 * grading!
 */
#define SBRK_SIZE 2048

/* If you want to use debugging printouts, it is HIGHLY recommended
 * to use this macro or something similar. If you produce output from
 * your code then you will receive a 20 point deduction. You have been
 * warned.
 */
#ifdef DEBUG
#define DEBUG_PRINT(x) printf x
#else
#define DEBUG_PRINT(x)
#endif


/* make sure this always points to the beginning of your current
 * heap space! if it does not, then the grader will not be able
 * to run correctly and you will receive 0 credit. remember that
 * only the _first_ call to my_malloc() returns the beginning of
 * the heap. sequential calls will return a pointer to the newly
 * added space!
 * Technically this should be declared static because we do not
 * want any program outside of this file to be able to access it
 * however, DO NOT CHANGE the way this variable is declared or
 * it will break the autograder.
 */
void* heap;

/* our freelist structure - this is where the current freelist of
 * blocks will be maintained. failure to maintain the list inside
 * of this structure will result in no credit, as the grader will
 * expect it to be maintained here.
 * Technically this should be declared static for the same reasons
 * as above, but DO NOT CHANGE the way this structure is declared
 * or it will break the autograder.
 */
metadata_t* freelist[8];
/**** SIZES FOR THE FREE LIST ****
 * freelist[0] -> 16
 * freelist[1] -> 32
 * freelist[2] -> 64
 * freelist[3] -> 128
 * freelist[4] -> 256
 * freelist[5] -> 512
 * freelist[6] -> 1024
 * freelist[7] -> 2048
 */

unsigned int heapOffset;    /*returned by first call to my_sbrk, used for deallocation */

void* my_malloc(size_t size)
{
  int blockSize, place, offset;
  metadata_t* block;
  
  /* the first call to my_malloc sets up the heap */
  if(heap == NULL) {
  	heap = my_sbrk(SBRK_SIZE);
  	heapOffset = (unsigned int) heap;
  	freelist[7] = (metadata_t*) heap;
  	freelist[7]->in_use = 0;
  	freelist[7]->size = 2048;
  	freelist[7]->next = NULL;
  	freelist[7]->prev = NULL;
  }
  
  
  blockSize = size + sizeof(metadata_t);
  if(blockSize > 2048)
  	return NULL;
  
  /* this is the smallest index in the free list that can fit our block */	
  place = logbase2(blockSize) - 4;
  
  /* this is used to increment through the indices of the freelist
     while the places are NULL (trying to find a block to split) */
  offset = 0;
  while((place+offset) < 8 && freelist[place + offset] == NULL)
  	offset++;
  
  /* if we get to position index 7 in the free list and it is NULL,
     we have run out of memory, so we call my_sbrk again */
  if(freelist[place+offset] == NULL) {
  	heap = my_sbrk(SBRK_SIZE);
  	freelist[7] = (metadata_t*) heap;
  	freelist[7]->in_use = 0;
  	freelist[7]->size = 2048;
  	freelist[7]->next = NULL;
  	freelist[7]->prev = NULL;
  }
  
  /* now we work back towards the smallest place that can fit our new
     block, splitting blocks as we go */
  while(offset>0) {
  	split(freelist[place+offset], place+offset);
  	offset--;
  }
  
  /* we remove the block from the freelist */
  block = freelist[place];
  if(freelist[place]->next != NULL) {
  	freelist[place] = freelist[place]->next;
 	 freelist[place]->prev = NULL;
  }
  
  else
  	freelist[place] = NULL;
  block->in_use = 1;
  block++;   /* metadata pointer + 1 gives us the pointer to the start of the user block */
  return (void*) block;
}

void* my_realloc(void* ptr, size_t new_size)
{
  unsigned int numBytes;
  void* newpointer;
  
  /* if ptr is null then it's just a call to malloc */
  if(ptr == NULL) 
  	return my_malloc(new_size);
  
  /* if size is 0 we just free the block */
  if(new_size == 0) {
  	my_free(ptr);
  	return NULL;
  }
  
  newpointer = my_malloc(new_size);
  if(newpointer == NULL)
  	return NULL;
  
  /* the number of bytes to copy is the smaller of the two blocks */	
  if( ((metadata_t*)ptr)->size < ((metadata_t*)newpointer)->size )
  	numBytes = ((metadata_t*)ptr)-> size;
  else
  	numBytes = ((metadata_t*)newpointer)->size;
  	
  my_memcpy(newpointer,ptr, numBytes);
  my_free(ptr); 
  return newpointer;
}

void my_free(void* pointer)
{
	int index;
	metadata_t* buddy;
	
	/* put the block in the free list and find the buddy */
	metadata_t* ptr = (metadata_t*) pointer;
	ptr--;		/* want the pointer to the metadata preceding the user block; */
	index = logbase2(ptr->size)-4;
	freelist[index]->prev = ptr;
	ptr->next = freelist[index];
	ptr->in_use = 0;
	freelist[index] = ptr;
	buddy = findBuddy(ptr);
	
	/* Keep merging while buddies are free */ 
	while((ptr->size < 2048) && (buddy->in_use == 0)) {
		ptr = merge(ptr,buddy,index);
		buddy = findBuddy(ptr);
		index++;
	}
	
}

void* my_memcpy(void* dest, const void* source, size_t num_bytes)
{
  int i;
  char* dst = (char*) dest;
  char* src = (char*) source;
  for (i=0; i<num_bytes; i++)
  	dst[i] = src[i];
  return (void*) dst;
}

int logbase2(int num) {
	if(num <= 1)
		return 0;
	return (logbase2(num/2) + 1);
}

void split(metadata_t* orig, int index) {
	metadata_t* new;
	int newsize;
	int size = orig->size;
	
	/* delete references to original block in freelist) */
	if(orig->next != NULL) {
		orig->next->prev = NULL;
		freelist[index] = orig->next;
	}
	
	else
		freelist[index] = NULL;
	
	newsize = size/2;
	new = (metadata_t*)(((char*)orig) + newsize + sizeof(metadata_t*));
	orig->size = newsize;
	orig->next = new;
	orig->prev = NULL;
	new->size = newsize;
	new->prev = orig;
	new->next = freelist[index-1];
	freelist[index-1] = orig;
}

metadata_t* findBuddy(metadata_t* orig) {
	
	/* n according to hw13malloc.txt */
	unsigned int n = logbase2(orig->size);
	
	/* here we subtract the heapOffset, flip the nth bit to find the buddy, and add the
	   heapOffset back to get the metadata* to the real buddy.   */
	unsigned int buddyAddress;
	metadata_t* buddy;
	orig = (metadata_t*)(((unsigned int) orig) - heapOffset);
	buddyAddress = ((unsigned int) orig)^(1<<n);
	buddy =(metadata_t*)(((char*) buddyAddress) + heapOffset);
	orig = (metadata_t*)(((char*) orig) + heapOffset);
	return buddy;
}

metadata_t* merge(metadata_t* first, metadata_t* second, int index) {
	int newsize;
	void* source, *dest;
	first->prev->next = first->next;          /* deleting references to first */
	first->next->prev = first->prev;
	second->prev->next = second->next;        /* deleting references to second */
	second->next->prev = second->prev;
	freelist[index] = first->next;		  /* take them out of free list  */  
	if (first > second)			  /* put in sequential order (simply swapping references here) */
		swap(first,second);
	
	newsize = first->size + second->size - sizeof(metadata_t);
	source = (void*)(((char*) second) + sizeof(metadata_t));   /*drop the metadata from second */
	dest = (void*)(((char*) first) + first->size); 		  /*set dest to right after first */
	my_memcpy(dest,source, (second->size - sizeof(metadata_t)));
	
	/* insert new block into next level of freelist */
	first->size = newsize;
	first->next = freelist[index+1];
	first->prev = NULL;
	freelist[index+1] = first;
	return first;			
}
	
void swap(metadata_t* a, metadata_t* b) {
	metadata_t temp = *a;
	*a = *b;
	*b = temp;
}	
