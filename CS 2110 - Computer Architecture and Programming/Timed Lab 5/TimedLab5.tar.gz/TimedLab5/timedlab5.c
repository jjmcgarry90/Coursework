/*====================================================================
 *     CS2110                Timed Lab 5                Fall 2010     
 *====================================================================
 * Filename: timedlab5.c
 * Author: 
 * Date: November 22, 2010
 * Assignment: Timed Lab 5 - GBA Mode 4 with DMA
 * Description: This is the skeleton file where you should put your code.
 */

#include "timedlab5lib.h"

/* The real palette in reverse */
/* You will combine the RGB values in zxymovie_palette here */
u16 the_real_palette[84];

int main(void)
{
	/* fill in your program here! */
	
	while(1)
	{

	}
	
	return 0;
}


/* END OF FILE */
