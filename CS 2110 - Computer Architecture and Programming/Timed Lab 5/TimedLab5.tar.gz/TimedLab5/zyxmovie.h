/*
 * Exported with BrandonTools v0.7
 * Invocation command was BrandonTools -mode4 zyxmovie movie.gif 
 * 
 * Image Information
 * -----------------
 * movie.gif (frame 0) 212@160
 * movie.gif (frame 1) 212@160
 * movie.gif (frame 2) 212@160
 * movie.gif (frame 3) 212@160
 * movie.gif (frame 4) 212@160
 * movie.gif (frame 5) 212@160
 * movie.gif (frame 6) 212@160
 * movie.gif (frame 7) 212@160
 * movie.gif (frame 8) 212@160
 * movie.gif (frame 9) 212@160
 * 
 * Quote/Fortune of the Day!
 * -------------------------
 * Protect me from knowing what I don't need to know.
 * Protect me from even knowing that there are things to know that I don't know.
 * Protect me from knowing that I decided not to know about the things that I decided not to know about.
 * Amen.~Douglas Adams, Mostly Harmless
 * 
 * All bug reports / feature requests are to be sent to Brandon (brandon.whitehead@gatech.edu)
 */

#ifndef ZYXMOVIE_BITMAP_H
#define ZYXMOVIE_BITMAP_H

#define ZYXMOVIE_PALETTE_SIZE 84*3

extern const unsigned short zyxmovie_palette[84*3];

extern const unsigned short movie0[16960];
#define MOVIE0_WIDTH 212
#define MOVIE0_HEIGHT 160

extern const unsigned short movie1[16960];
#define MOVIE1_WIDTH 212
#define MOVIE1_HEIGHT 160

extern const unsigned short movie2[16960];
#define MOVIE2_WIDTH 212
#define MOVIE2_HEIGHT 160

extern const unsigned short movie3[16960];
#define MOVIE3_WIDTH 212
#define MOVIE3_HEIGHT 160

extern const unsigned short movie4[16960];
#define MOVIE4_WIDTH 212
#define MOVIE4_HEIGHT 160

extern const unsigned short movie5[16960];
#define MOVIE5_WIDTH 212
#define MOVIE5_HEIGHT 160

extern const unsigned short movie6[16960];
#define MOVIE6_WIDTH 212
#define MOVIE6_HEIGHT 160

extern const unsigned short movie7[16960];
#define MOVIE7_WIDTH 212
#define MOVIE7_HEIGHT 160

extern const unsigned short movie8[16960];
#define MOVIE8_WIDTH 212
#define MOVIE8_HEIGHT 160

extern const unsigned short movie9[16960];
#define MOVIE9_WIDTH 212
#define MOVIE9_HEIGHT 160

#endif