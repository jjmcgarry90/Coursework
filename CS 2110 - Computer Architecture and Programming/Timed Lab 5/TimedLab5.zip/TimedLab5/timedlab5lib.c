/*====================================================================
 *     CS2110                Timed Lab 5                Fall 2010          
 *====================================================================
 * Filename: timedlab5lib.c
 * Author: 
 * Date: November 22, 2009
 * Assignment: Timed Lab 5 - GBA Mode 4 with DMA
 * Description: This is a library file.
 */ 

#include "timedlab5lib.h"
#include <stdlib.h>

u16* videoBuffer = (u16*) 0x6000000;
u16* palette = (u16*) 0x5000000;
u16* frontBuffer = (u16*) 0x6000000;
u16* backBuffer = (u16*) 0x600A000;

void waitForVblank()
{
	while(SCANLINECOUNTER > 160);
	while(SCANLINECOUNTER < 160);
}

void flipPage(void)
{
	if(REG_DISPCNT & BACKBUFFER)
	{
		REG_DISPCNT &= ~BACKBUFFER;
		videoBuffer = backBuffer;
	}
	else
	{
		REG_DISPCNT |= BACKBUFFER;
		videoBuffer = frontBuffer;
	}
} 
