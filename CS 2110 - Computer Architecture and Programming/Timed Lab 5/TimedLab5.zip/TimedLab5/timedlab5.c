/*====================================================================
 *     CS2110                Timed Lab 5                Fall 2010     
 *====================================================================
 * Filename: timedlab5.c
 * Author: 
 * Date: November 22, 2010
 * Assignment: Timed Lab 5 - GBA Mode 4 with DMA
 * Description: This is the skeleton file where you should put your code.
 */

#include "timedlab5lib.h"
#include "zyxmovie.h"

/* The real palette in reverse */
/* You will combine the RGB values in zxymovie_palette here */
void setPalette() {
	u16 the_real_palette[84];
	int i;
	for(i = 84*3-1; i > 0; i-=3)
	  the_real_palette[i/3] = zyxmovie_palette[i] |  (zyxmovie_palette[i-1] << 5) | (zyxmovie_palette[i-2] << 10);
	 
	REG_DMA3SAD =  (vu32) &(the_real_palette) + 83;
	REG_DMA3DAD =  (vu32) palette;
	REG_DMA3CNT = DMA_ON | DMA_SOURCE_DECREMENT;
}


int main(void)
{
	/* fill in your program here! */
	REG_DISPCNT = MODE4 | BG2_ENABLE;
	setPalette();
	while(1)
	{
	waitForVblank();
	flipPage();
	}
	
	return 0;
}


/* END OF FILE */
