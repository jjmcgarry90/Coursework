/*
 * Exported with BrandonTools v0.7
 * Invocation command was BrandonTools -mode3 title satlgiii.png 
 * 
 * Image Information
 * -----------------
 * satlgiii.png 240@160
 * 
 * Quote/Fortune of the Day!
 * -------------------------
 * He who believes that the past cannot be changed has not yet written his memoirs. ~Torvald Gahlin
 * 
 * All bug reports / feature requests are to be sent to Brandon (brandon.whitehead@gatech.edu)
 */

#ifndef TITLE_BITMAP_H
#define TITLE_BITMAP_H

extern const unsigned short title[38400];
#define TITLE_WIDTH 240
#define TITLE_HEIGHT 160

#endif