/* FIXME
   The videoBuffer is located at address 0x6000000
   The videoBuffer contains 38400 shorts.
   where the first one is at location 0x6000000
   the next one is at location 0x6000002
   Define a VARIABLE named videoBuffer that can be used
   to access all 38400 pixels.
 */

void setPixel(int r, int c, u16 color)
{
	/* FIXME IMPLEMENT THIS */
}

void waitForVBlank()
{
	/* FREEBIE :D */
	while(SCANLINECOUNTER > 160);
	while(SCANLINECOUNTER < 160);
}

/* Clears the screen
 * Please clear the screen in any color
 * of your choosing other than black.
 * You must use your RGB Macro declared in mylib.h
 */
void clearScreen(u16 color)
{
	/* FIXME Implement this */
}

/* Draws the cursor which is just the portion of the 
 * image the cursor is currently located
 */
void drawCursor(Cursor cursor)
{
 /* FIXME Implement this */
 /* Note you will need to reference the mystery array in this function */
}

/* Draws the AWESOME TITLE SCREEN using set pixel */
void drawTitle()
{
	/* FIXME Implement this */
}
