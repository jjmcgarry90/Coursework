int main(void)
{

	/* Define a variable of type Cursor here
	and initialize it to whatever you want
	(as long as it makes sense!) */
	
	/* Set up REG_DISPCNT using 
	The SETMODE MACRO you defined in timedlablib.h
	The SYMBOLS BG2_ENABLE and MODE3 are already defined for you
	*/
	
	while(1)
	{
		/* Wait for Vertical Blank */
		waitForVBlank();
	}
	
	return 0;
}
