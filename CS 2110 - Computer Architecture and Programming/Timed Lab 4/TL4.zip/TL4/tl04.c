#include "timedlablib.h"
#include "title.h"
#include "mystery.h"

int main(void)
{

	/* Define a variable of type Cursor here
	and initialize it to whatever you want
	(as long as it makes sense!) */
	Cursor curs;
	curs.row = 5;
	curs.col = 5;
	curs.height=5;
	curs.width =5;
	/* Set up REG_DISPCNT using 
	The SETMODE MACRO you defined in timedlablib.h
	The SYMBOLS BG2_ENABLE and MODE3 are already defined for you
	*/
	REG_DISPCNT = SETMODE(BG2_ENABLE,MODE3);
	
	drawTitle(title);
	while(!KEY_DOWN_NOW(BUTTON_START)) {}
	clearScreen(RGB(5,5,5));
	while(1)
	{
		/* Wait for Vertical Blank */
		waitForVBlank();
		drawCursor(curs);
		if (KEY_DOWN_NOW(BUTTON_RIGHT) 
		 curs.col +=1;
		if (KEY_DOWN_NOW(BUTTON_LEFT) 
		 curs.col -=1;
		if (KEY_DOWN_NOW(BUTTON_UP) 
		 curs.row -=1;
		if (KEY_DOWN_NOW(BUTTON_DOWN) 
		 curs.col +=1;
	}
	
	return 0;
}
