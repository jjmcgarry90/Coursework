#include "game.h"

/* The current state we are in */
int state = 0;

void title(void)
{
	printf("*************************************************************\n");
	printf("*                      Guess My Number                      *\n");
	printf("*************************************************************\n");
}

void random_gen(void)
{
	/* Generate a random number here */
}

int guess(void)
{
	/* Prompt the user for an int */
	/* "Read" in an int here */
	/* Return the int */
}

int check(int guess)
{
	/* Compare the guess with the random number */
	/* Return -1 if lower 0 if win 1 if higher */
}

int report(int result)
{
	/* Print out the appropriate message */
	/* Remember to go to the correct state afterward */
}

int play_again(void)
{
	/* Ask the user if he wants to play again */
	/* Ask for a character Y/N */
	/* Return 1 if the user wants to play again 0 if he wants to quit */
}
