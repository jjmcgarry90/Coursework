#ifndef GAME_H
#define GAME_H

enum
{
	TITLE,
	RANDOM_GEN,
	GUESS,
	CHECK,
	REPORT,
	PLAYAGAIN
};

void title(void);
void random_gen(void);
int guess(void);
int check(int);
void report(int);
void play_again(void);

#endif
