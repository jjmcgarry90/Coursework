#ifndef RANDLIB_H
#define RANDLIB_H

int random_range(int, int);
int random(int);

#endif
