#ifndef IO_H
#define IO_H

int scan_nextInt(void);
int scan_next(void);

#endif
