#include <stdlib.h>
#include "mylib.h"
#include "mystery.h"

extern const u16 mystery[38400];

int main(void)
{
		/*int i, j; */
    REG_DISPCNT = MODE3 | BG2_ENABLE;
    		/*
		 Hey fix this Draw the image with DMA instead ;D 
		for (i = 0; i < 160; i++)
		{
			for (j = 0; j < 240; j++)
			{
				setPixel(j, i, mystery[240 * i + j]);
			}
		}
		*/
		
		DMA[3].src = mystery;
		DMA[3].dst = videoBuffer;
		DMA[3].cnt = DMA_ON | 38400;
    while (1)
    {
    	u16 black = 0;
        waitForVblank();
        DMA[3].src = &black;
        DMA[3].dst = videoBuffer;
        DMA[3].cnt = DMA_ON | DMA_SOURCE_FIXED | 38400;
				/* Clear the screen here using DMA */
				
				/* Of course in a real mode3 game you don't have enough time to DMA clear the whole screen but just go with me here*/
    }
}
