#include <stdlib.h>
#include "mylib.h"
#include "mystery.h"

extern const u16 mystery[38400];

int main(void)
{
    REG_DISPCNT = MODE3 | BG2_ENABLE;

    while (1)
    {
        waitForVblank();
        DMA[3].src = mystery + 38399;
        DMA[3].dst = videoBuffer;
        DMA[3].cnt = DMA_ON | DMA_SOURCE_DECREMENT | 38400;
        /* Draw the mystery image (it is flipped horizontally and vertially)) stored in the array mystery defined in mystery.c onto the screen here*/
        /* Hint: start at the last pixel of the image and draw it in reverse */
							
							
				/* Now consider this what if the image was just flipped horizontally how could you draw it correctly with DMA? */
				
				/* Then consider if the image was just flipped vertically how could you draw it correctly with DMA? */
    }
}
