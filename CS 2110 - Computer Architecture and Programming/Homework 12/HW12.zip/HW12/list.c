/**
 * CS 2110 - Fall 2010 - Homework #12
 * Edited by: Joshua Cranmer
 *
 * list.c: Complete the functions!
 **/

#include <stdlib.h>
#include <stdio.h>
#include "list.h"

/**
 * Creates a llist
 *
 * Be sure to initialize size to zero
 * And head to NULL.
 **/
llist* create_list(void)
{
  llist* list;
  list = malloc(sizeof(list));
  list->size = 0;
  list->head = NULL;
  return list;
}

/**
 * Creates a lnode
 *
 * void* data: data this node will contain.
 **/
lnode* create_node(void* data)
{
  lnode* node;
  node = malloc(sizeof(node));
  node->prev = NULL;
  node->next = NULL;
  node->data = data;
  
  return node;
}

/**
 * Adds a node to the front of a linked list.
 *
 * llist* list: a pointer to a linked list
 * lnode* node: a pointer to a linked list node to add
 **/
void add_front(llist* list, lnode* node)
{
  if(list->size == 0) {
  	node->next = node;
  	node->prev = node;
  	list->head = node;
  }
  	
   
  else {
  	node->next = list->head;
  	node->prev = list->head->prev;
  	node->prev->next = node;
  	list->head->prev = node;
  	list->head = node;
  }
  
  list->size++;
}

/**
 * Adds a node to the back of a linked list.
 *
 * llist* list: a pointer to a linked list
 * lnode* node: a pointer to a linked list node to add
 **/
void add_back(llist* list, lnode* node) 
{
  if(list->size == 0) {
  	list->head = node;
  	node->next = node;
  	node->prev = node;
  }
  
  else {
  	node->next = list->head;
  	node->prev = list->head->prev;
  	list->head->prev->next = node;
  	list->head->prev = node;
  }
  
  list->size++;
}

/**
 * Removes a node from the front of a linked list.
 *   The removed node should be freed.
 *
 * llist* list: a pointer to a linked list.
 * list_op free_func: a function pointer to the node's free function.
 *
 * Returns 0 if the remove was successful, or 1 if the list was empty
 **/
int remove_front(llist* list, list_op free_func) {
  if(list->size == 0)
  	return 1;
  else {
  	lnode* node = list->head;
  	node->prev->next = node->next;
  	node->next->prev = node->prev;
  	list->head = node->next;
  	free_func(node);
  	list->size--;
  	return 0;
  }
}


/**
 * Removes a node from the back of a linked list.
 *   The removed node should be freed.
 *
 * llist* list: a pointer to a linked list.
 * list_op free_func: a function pointer to the node's free function.
 *
 * Returns 0 if the remove was successful, or 1 if the list was empty
 **/
int remove_back(llist* list, list_op free_func)
{
  if(list->size == 0) 
     return 1;
  else {
     lnode* node = list->head->prev;
     node->prev->next = list->head;
     list->head->prev = node->prev;
     free_func(node);
     list->size--;
     return 0;
  }
}

/**
 * Searches for the first node in the forward direction with data equal to the
 *   data parameter.
 *
 * llist* list: a pointer to a linked list.
 * void* data: data to search for.
 * compare_op compare: comparison function used to compare two data items.
 *
 * Returns a pointer to the node if found, or NULL if not found.
 **/
lnode* find_occurrence(llist* list, void* search, compare_op compare)
{
  void* current = list->head;
  int i;
  for(i = 0; i < list->size; i++) {
  	if(data_compare(current, search) == 0)
  		return (lnode*) current;
  	current = ((lnode*) current)->next;
  	current = (void*) current;
  }
  return NULL;
}

/**
 * Frees an entire list.
 *
 * llist* list: a pointer to a linked list.
 * list_op free_func: function used to free a node
 *
 *  Do NOT free the list itself, only its nodes.
 **/
void free_list(llist* list, list_op free_func)
{
	int i;
	for(i = 0; i <= list->size; i++) {
		remove_front(list, free_func);
	}
}

/**
 * Traverses a linked list and calls do_func on each node.
 * llist* list: a pointer to a linked list.
 * list_op do_func: function pointer that should be called on each node.
 */
void traverse(llist* list, list_op do_func)
{
	lnode* current = list->head;
	int i;
	for (i = 0; i<list->size; i++) {
		do_func(current);
		current = current->next;
	}
}

/**
 * Prints the node's data.
 * For this default implementation
 * Just call printf with the data
 * Use the %p for pointer for this.
 */
void print_node(lnode* node)
{
     printf("%p", node->data);
}

/**
 * Free's the node's data.
 * For this default implementation
 * Just free the node's data.
 * And the node.
 */
void free_node(lnode* node)
{
  free(node->data);
  free(node);
}

/**
 * Compares two node's data items
 * Returns a negative if a < b
 * Returns a positive if a > b
 * Returns zero if a == b
 * For this default implementation
 * just return a - b as an int
 */
int data_compare(const void* a, const void* b)
{  
  lnode* pa = ((lnode*) a);
  lnode* pb = ((lnode*) b);
  return ((int)pa->data - (int)pb->data);  
}
