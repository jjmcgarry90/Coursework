/*
 * Exported with BrandonTools v0.7
 * Invocation command was BrandonTools -mode4 fall1 fall1.bmp fall2.bmp fall3.bmp fall4.bmp 
 * 
 * Image Information
 * -----------------
 * fall1.bmp 20@20
 * fall2.bmp 20@20
 * fall3.bmp 20@20
 * fall4.bmp 20@20
 * 
 * Quote/Fortune of the Day!
 * -------------------------
 * May those who love us love us,
 *  and those who do not love us,
 *  may God turn their hearts,
 *  and if He cannot turn their hearts
 *  may He turn their ankles
 *  that we may know them by their limping.
 *  ~Irish Prayer
 * 
 * All bug reports / feature requests are to be sent to Brandon (brandon.whitehead@gatech.edu)
 */

#ifndef FALL1_BITMAP_H
#define FALL1_BITMAP_H

#define FALL1_PALETTE_SIZE 4

extern const unsigned short fall1_palette[4];

extern const unsigned short fall1[200];
#define FALL1_WIDTH 20
#define FALL1_HEIGHT 20

extern const unsigned short fall2[200];
#define FALL2_WIDTH 20
#define FALL2_HEIGHT 20

extern const unsigned short fall3[200];
#define FALL3_WIDTH 20
#define FALL3_HEIGHT 20

extern const unsigned short fall4[200];
#define FALL4_WIDTH 20
#define FALL4_HEIGHT 20

#endif