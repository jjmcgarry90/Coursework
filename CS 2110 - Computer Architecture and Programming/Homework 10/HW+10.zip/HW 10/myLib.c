#include "myLib.h"

unsigned short *videoBuffer = (unsigned short *)0x6000000;

void drawAnimation(ANIMATION anim) {
	drawImage4(anim.row,anim.col,anim.height,anim.width,		 			   anim.image[anim.cur]);
}

void updateAnimation(ANIMATION anim) {
	if(anim.count >= anim.delay) {
		anim.count = 0;
		anim.cur++;
	}
	
	if(anim.cur >= anim.max)
		anim.cur = 0;
	anim.count++;
}
void drawRect4(int row, int col, int ht, int wid, unsigned char index)
{
	int r;
	volatile u16 color = index<<8 | index;
	col = col /2 *2;
	for(r=0; r<ht; r++) {
	
		if(col >= 0 && col+wid <= 240){ 
		   DMA[3].src = &color;
		   DMA[3].dst = &videoBuffer[OFFSET(row+r, col, 240)/2];
		   DMA[3].cnt = DMA_ON | DMA_SOURCE_FIXED | (wid/2);
		}
		
		
		if(col < 0 && col+wid > 0){ 
		   DMA[3].src = &color;
		   DMA[3].dst = &videoBuffer[OFFSET(row+r, 0, 240)/2];
		   DMA[3].cnt = DMA_ON | DMA_SOURCE_FIXED | 					((wid+col)/2);
		}
		
	}
}

void drawImage4(int row, int col, int ht, int wid, const unsigned short *image)
{
	
	int r;
	col = col/2*2;
	for(r=0; r<ht; r++)
	{
		DMA[3].src = image;
		DMA[3].dst = videoBuffer + OFFSET(row+r, col, 240)/2;
		DMA[3].cnt = DMA_ON | (wid/2);
		image += (wid/2);
	}
}


void drawRect(int row, int col, int ht, int wid, unsigned short color)
{
	
	int r;
	for(r=0; r<ht; r++)
	{
		
		DMA[3].src = &color;
		DMA[3].dst = &videoBuffer[OFFSET(row+r, col, 240)];
		DMA[3].cnt = DMA_ON | DMA_SOURCE_FIXED | wid;
	
	}
}

	
	
	

void setPixel(int r, int c, unsigned short color)
{
	videoBuffer[OFFSET(r,c,NUMCOLS)] = color;
}

void setPixel4(int r, int c, unsigned char index)
{
	int pixel = OFFSET(r,c,240);
	if(c & 1)
	{	/* Odd column */
		videoBuffer[pixel/2] = (videoBuffer[pixel/2] & 0x00FF) | (index<<8);
	}
	else
	{	/* Even column */
		videoBuffer[pixel/2] = (videoBuffer[pixel/2] & 0xFF00) | index;
	}
}
		


void delay(int n)
{
	int i;
	volatile int y;
	for(i=0; i<n; i++)
	{
		y = i*n;
	}
}

void waitForVblank()
{
	while(SCANLINECOUNTER > 160);
	while(SCANLINECOUNTER < 160);
}

int rectCollides(RECT a, RECT b) {
	if((a.col+a.width >= b.col && a.col <= b.col+b.width) && 
	(a.row+a.height >= b.row && a.row <= b.row+b.height))
		return 1;
	else
		return 0;
}	

void setPalette(u16* pal, int size) {
	DMA[3].src = pal;
	DMA[3].dst = PALETTE;
	DMA[3].cnt = DMA_ON | size;
}

void FlipPage()
{
	if(REG_DISPCTL & BUFFER1FLAG)
	{
		REG_DISPCTL &= ~BUFFER1FLAG;
		videoBuffer = BUFFER1;
	}
	else
	{
		REG_DISPCTL |= BUFFER1FLAG;
		videoBuffer = BUFFER0;
	}
}
