#ifndef TEXT_H
#define TEXT_H

void drawChar4(int row, int col, char ch, int index);
void drawString4(int row, int col, char str[], int index);
extern const unsigned char fontdata[1536];
#define TEXT_WIDTH 6
#define TEXT_HEIGHT 8

#endif
