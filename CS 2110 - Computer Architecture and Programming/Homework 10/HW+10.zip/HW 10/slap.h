/*
 * Exported with BrandonTools v0.7
 * Invocation command was BrandonTools -mode4 -resize=240,160 slap slap.jpg 
 * 
 * Image Information
 * -----------------
 * slap.jpg 240@160
 * 
 * Quote/Fortune of the Day!
 * -------------------------
 * May those who love us love us,
 *  and those who do not love us,
 *  may God turn their hearts,
 *  and if He cannot turn their hearts
 *  may He turn their ankles
 *  that we may know them by their limping.
 *  ~Irish Prayer
 * 
 * All bug reports / feature requests are to be sent to Brandon (brandon.whitehead@gatech.edu)
 */

#ifndef SLAP_BITMAP_H
#define SLAP_BITMAP_H

extern const unsigned short slap[19200];
extern const unsigned short slap_palette[83];
#define SLAP_WIDTH 240
#define SLAP_HEIGHT 160
#define SLAP_PALETTE_SIZE 83

#endif