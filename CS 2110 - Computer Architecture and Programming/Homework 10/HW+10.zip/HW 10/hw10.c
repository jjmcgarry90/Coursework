#include <stdlib.h>
#include <stdio.h>
#include "myLib.h"
#include "text.h"
#include "slap.h"
#include "fall1.h"

RECT craft, dodge;
ANIMATION anim;
int speed;
int score,newScore;
char text[41];
char inst[41];
char scorebuf[41];
char newScorebuf[41];

/* Sets up initial values and locations of in-game objects */
void initialize() {
	REG_DISPCTL = MODE4 | BG2_ENABLE;
	craft.row = 80; craft.col = 50;
	craft.width = 18; craft.height = 18;
	dodge.width = 18, dodge.height=18;
	dodge.row = rand() % (160-dodge.height);
	dodge.col = 240;
	anim.width = 20; anim.height= 20;
	anim.row= 100; anim.col = 110;
	anim.cur=0; anim.max = 3;
	anim.count = 0; anim.delay=1000;
	anim.image[0]= fall1;
	anim.image[1]= fall2;
	anim.image[2]= fall3;
	anim.image[3]= fall4;
	speed = 6;
	newScore = 0;
}

/* Draws black where objects are located to clear screen */
void clear() {
	drawRect4(0,0,160,240,0);
}

/* Creates the animation in the program by changing the properties
   of the objects */
void update() {
	sprintf(scorebuf,"%d",score);
	sprintf(newScorebuf,"%d",newScore);
	dodge.col-= speed;
	if(dodge.col+dodge.width < 0) {
		dodge.col = 240;
		dodge.row = rand()%(160-dodge.height); 
		newScore++;
	}
	

	if(KEY_DOWN_NOW(BUTTON_UP))
		craft.row-=2;
	if(KEY_DOWN_NOW(BUTTON_DOWN))
		craft.row+=2;
	if(KEY_DOWN_NOW(BUTTON_LEFT))
		craft.col-=2;
	if(KEY_DOWN_NOW(BUTTON_RIGHT))
		craft.col+=2; 
		
	if(craft.col < 0)
		craft.col = 0;
	if(craft.col+craft.width > 239)
		craft.col = 239-craft.width;
	if(craft.row < 0)
		craft.row = 0;
	if(craft.row+craft.height > 159)
		craft.row = 159-craft.height;
	
	score = newScore;

			
	if(KEY_DOWN_NOW(BUTTON_SELECT))
		title();
}

/* Draws the interactive in-game objects */
void draw() {
	drawRect4(dodge.row,dodge.col,dodge.height,dodge.width,1);
	drawString4(159,10,newScorebuf,1); 
	drawRect4(craft.row,craft.col,craft.height,craft.width,1);
	if(rectCollides(craft,dodge))
		slapScreen(); 
	}

/* Code to set up the title screen text */
void title()  {
	PALETTE[1] = BLUE;
	sprintf(text, "NOT THE FACE!");
	drawString4(80,80,text,1);
	
	sprintf(text, "Press Start");
	drawString4(140,85,text,1);
	
	sprintf(inst, "(use the arrow keys to dodge)");
	drawString4(130,32,inst,1);
	
	setPalette(fall1_palette,4); 
	drawAnimation(anim);
	
	while(!KEY_DOWN_NOW(BUTTON_START)){
	    updateAnimation(anim);
	    anim.cur++;
	    drawAnimation(anim);  
	}
	clear();
	initialize();
}

/* Sets up the screen after a collision occurs */
void gameOver() {
	clear();
	PALETTE[1] = BLUE;
	sprintf(text,"GAME OVER");
	drawString4(60,85,text,1);
	sprintf(text,"You dodged %d slap(s)!",newScore);
	drawString4(80,53,text,1);
	delay(1000000);
	drawString4(80,53,text,0);
	sprintf(text,"GAME OVER");
	drawString4(60,85,text,0);
	title();
}

void slapScreen() {
	clear(); 
	setPalette(slap_palette, 83);
	drawRect(0,0,10,10,50);
	drawImage4(0,0,160,240,slap); 
	delay(500000);
	clear();
	gameOver();
}
	
/* Runs the game */
int main(void) {
	initialize();
	title();
	while(1) {
		waitForVblank();
		clear();
		update();
		draw();
		
	}
	
	return 0;
}
