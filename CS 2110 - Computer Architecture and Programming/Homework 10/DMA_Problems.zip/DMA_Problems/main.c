#include <stdlib.h>
#include "mylib.h"

void drawRect(int r, int c, int width, int height, vu16 color);
void drawCheckeredRect(int r, int c, int width, int height, vu16 color, vu16 color2);

int main(void)
{
    int i, j;
    REG_DISPCNT = MODE3 | BG2_ENABLE;

    while (1)
    {
	waitForVblank();


        for (i = 0; i < 20; i++)
        {
           	for (j = 0; j < 30; j++)
           	{
           			int index = i * 30 + j;

           			/* Try to figure out what this line of code is doing */
           			/* Note ? : is the conditional operator much like in java it is equivalent to an if else where
           			 condition ? iftruethishappens : iffalsethishappens
           			 */
           			drawRect(i * 8, j * 8, 8, 8, ((index & 1) ^ (i & 1)) ? RGB(0, 0, 0) : RGB(31, 31, 31));
           	}
        }
    }
}

/* Draws a rectangle */
/* Upon success when the game is ran a checkboard should appear */
void drawRect(int r, int c, int width, int height, vu16 color)
{
}

/* Now all of you should be able to code the above function now consider this one
 how this one works is you are given two colors and it should draw a checkered rect
 what I mean by this is say I have two colors red and blue if I pass these as the colors
 for this function then I should get something like this

 rbrbrbrbrbrb
 brbrbrbrbrbr
 rbrbrbrbrbrb
 brbrbrbrbrbr
 rbrbrbrbrbrb
 brbrbrbrbrbr
 rbrbrbrbrbrb

 */
void drawCheckeredRect(int r, int c, int width, int height, vu16 color, vu16 color2)
{
	int i;

	for (i = 0; i < height; i++)
	{
		/* Now set the DMA registers here */
	}
}

/*
 This function is called blit or a bitblock-transfer you don't need to learn these terms for this class
 but if you want to learn more here is the wikipedia article http://en.wikipedia.org/wiki/Bit_blit

 So you will write this function called blit it takes six parameters
 the destination row (dr) and destination col (dc) which tells where the image will go.

 and the last four parameters (sr, sc, swidth, sheight) give the dimensions and location of the bounding box of the image

 YOU MUST IMPLEMENT THIS FUNCTION USING DMA.

 You may assume all parameters passed in are even.
*/
void blit(int dr, int dc, int sr, int sc, int swidth, int sheight)
{
}
