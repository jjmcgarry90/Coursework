// SortingAlgorithms.java

/** HW7 Sorter class.  You will call this from your Driver class to 
 * measure your different sorts.*/
public class SortingAlgorithms {

	/**
	* Sorts the given array of ints using selection sort.
	* The sort should sort the ints from least to greatest.
	* Feel free to write helper methods if needed.
	* @param array, the array to be sorted
	* @return int[] array, the sorted array
	*/
	public int[] selectionSort(int[] array) {
		//TODO: Implement selection sort here!
		return array;  //change this if you want
	}

	/**
	* Sorts the given array of ints using insertion sort.
	* The sort should sort the ints from least to greatest. 
	* Feel free to write helper methods if needed.
	* @param array the array to be sorted 
	* @return int[] array, the sorted array
	*/
	public int[] insertionSort(int[] array) {
		//TODO: Implement insertion sort here!
		return array;  //change this if you want
	}
	
	/**
	* Sorts the given array of ints using radix sort. You can
	* assume that the array contains ints of the same length.
	* The sort should sort the ints from least to greatest. 
	* Feel free to write helper methods if needed.
	* @param array the array to be sorted 
	* @return int[] array, the sorted array
	*/
	public int[] radixSort(int[] array) {
		//TODO: Implement radix sort here!
		return array;  //change this if you want
	}
	
	/**
	* Sorts the given array of ints using merge sort.
	* The sort should sort the ints from least to greatest.
	* Feel free to write helper methods if needed.
	* @param array, the array to be sorted
	* @return int[] array, the sorted array
	*/
	public int[] mergeSort(int[] array) {
		//TODO: Implement merge sort here!
		return array;  //change this if you want
	}

	/**
	* Sorts the given array of ints using inplace quick sort.
	* The sort should sort the ints from least to greatest 
	* and always pick pivots randomly.
	* Feel free to write helper methods if needed.
	* @param array the array to be sorted 
	* @return int[] array, the sorted array
	*/
	public int[] inPlaceQuickSort(int[] array) {
		//TODO: Implement inplace quick sort here!
		return array;  //change this if you want
	}
}